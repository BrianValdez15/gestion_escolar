/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion_escolar;

/**
 *
 * @author yahir izael reyes
 */
public class escuela {
    private String nombre,direccion;
    private int clave,telefono;
    public void escuela(String nombre,String direccion,int clave,int telefono){
        this.nombre = this.nombre;
        this.direccion = this.direccion;
        this.clave = this.clave;
        this.telefono = this.telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getClave() {
        return clave;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
   
}
