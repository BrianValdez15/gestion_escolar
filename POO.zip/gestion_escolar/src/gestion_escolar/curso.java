/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion_escolar;

/**
 *
 * @author yahir izael reyes
 */
public class curso {
   private int salon,grado;
    public curso(int Salon, int grado){
     this.salon = this.salon;
      this.grado = this.grado;
          System.out.println(3);
    }

    public int getSalon() {
        return salon;
    }

    public void setSalon(int salon) {
        this.salon = salon;
    }

    public int getGrado() {
        return grado;
    }

    public void setGrado(int grado) {
        this.grado = grado;
    }
  
}
